#include "Huffmann.cpp"
using namespace std;
using namespace Tree;

int main()
{
    Binary<int> intABB;
    intABB.inserir({2, 3});
    intABB.inserir({4, 8});
    intABB.inserir({9, 5});
    intABB.inserir({1, 5});
    intABB.inserir({3, 7});
    Binary<string> mathTree;
    mathTree.inserir({8, "+"});
    mathTree.inserir({4, "*"});
    mathTree.inserir({2, "-"});
    mathTree.inserir({1, "6"});
    mathTree.inserir({3, "3"});
    mathTree.inserir({6, "+"});
    mathTree.inserir({5, "4"});
    mathTree.inserir({7, "1"});
    mathTree.inserir({9, "5"});
    Binary<int> arvoreDesbalacenada;
    arvoreDesbalacenada.inserir(new Binary<int>({4, 5})); //O numero 5 nao importa, apenas as chaves serao importantes
    arvoreDesbalacenada.insertLeft(new Binary<int>({4, 5}));
    arvoreDesbalacenada.insertRight(new Binary<int>({2, 5}));
    arvoreDesbalacenada.esq->insertLeft(new Binary<int>({9, 5}));
    arvoreDesbalacenada.esq->insertRight(new Binary<int>({4, 5}));
    arvoreDesbalacenada.dir->insertLeft(new Binary<int>({-89, 5})); 
    Binary<int> *questao1 = intABB.procuraNoNaoRecursivo(9);
    cout << "Questao 1: " << questao1->getKey() << "-> " << (int)questao1->getInfo() << endl;

    int questao2 = intABB.contagemDeNosNaoFolha();
    cout << "Questao 2: " << questao2 << endl;

    int questao3 = mathTree.calcularArvoreDeOperacoes();
    cout << "Questao 3: " << questao3 << endl;

    int maiorCamada = 0;
    bool questao4 = intABB.testaBalanceado(maiorCamada);
    cout << "Questao 4: " << std::boolalpha << questao4 << std::noboolalpha << endl;

    cout << "Questao 5: ";
    int aux = arvoreDesbalacenada.getKey();
    arvoreDesbalacenada.calcularMaiorSemOrdenacao(aux);
    cout << "Maior Valor: " << (int)aux << ", ";
    aux = arvoreDesbalacenada.getKey();
    arvoreDesbalacenada.calcularMenorSemOrdencao(aux);
    cout << "Menor Valor: " << (int)aux;
}